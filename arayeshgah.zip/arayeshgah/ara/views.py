from django.shortcuts import render
from django.views.generic import ListView,CreateView,FormView,DetailView
from .models import Appointments, WorkSamples,Personel,Course,Service,Category,TimeSlot
from .forms import AppointmentForm
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
import datetime
from django.http import JsonResponse
# Create your views here.


today_min = datetime.datetime.combine(datetime.date.today(), datetime.time.min)
from django.shortcuts import render

def personel_appointments(request, personel_id):
    personel = Personel.objects.get(id=personel_id)
    appointments = personel.appointments.all()

    context = {
        'personel': personel,
        'appointments': appointments
    }

    return render(request, 'personel_appointments.html', context)


class PersonelAppointmentListView(LoginRequiredMixin, ListView):
    template_name = 'appointments/personel_appointment_list.html'
    context_object_name = 'appointments'

    def get_queryset(self):
         current_personel = Personel.objects.filter(user=self.request.user).first()

        # لیست رزروهایی که با پرسنل فعلی انجام شده اند
         appointments = Appointments.objects.filter(personel=current_personel)

         return appointments
     
class WorkSamplesListView(ListView):
        model=WorkSamples   
        template_name='appointments/work_samples.html'


class CoursesList(ListView):
    model=Course
    template_name='appointments/courses_list.html'


def update_services(request):
    category_id = request.GET.get('category_id')
    services = Service.objects.filter(category_id=category_id)
    print(services)
    data = {
        'services': [{'id': service.id, 'title': service.title} for service in services],
    }
    return JsonResponse(data)


def update_personels(request):
    service_id = request.GET.get('service_id')
    personels = Personel.objects.filter(services__id=service_id)
 
    data = {
        'personels': [{'id': personel.id, 'nme': personel.nme} for personel in personels],
    }
    return JsonResponse(data)

def appointment_form(request):
    categories = Category.objects.all()
    services = Service.objects.none()
    personels = Personel.objects.none()
    times

    if request.method == 'POST':
        category_id = request.POST.get('category')
        service_id = request.POST.get('service')
        personel_id = request.POST.get('personel')

        category = Category.objects.filter(id=category_id).first()
        if category:
            services = category.services.all()

        service = Service.objects.filter(id=service_id).first()
        if service:
            personels = service.personel_set.all()

        form = AppointmentForm(request.POST)

        if form.is_valid():
            # Save the appointment to the database
            appointment = form.save(commit=False)
            appointment.category = category
            appointment.service = service
            appointment.personel = Personel.objects.filter(id=personel_id).first()
            appointment.save()

            # Redirect to a success page
            return redirect('appointment_success')
    else:
        form = AppointmentForm()

    context = {
        'categories': categories,
        'services': services,
        'personels': personels,
        'form': form,
    }

    return render(request, 'appointment_form.html', context)




def save_appointment(request):
    if request.method == 'POST':
        category_id = request.POST.get('category')
        personel_id = request.POST.get('personel')
        service_id = request.POST.get('service')
        date = request.POST.get('date')
        time_slot_id = request.POST.get('time_slot')

        # Perform validation and save the appointment data to the database
        category = Category.objects.get(id=category_id)
        personel = Personel.objects.get(id=personel_id)
        service = Service.objects.get(id=service_id)
        time_slot = TimeSlot.objects.get(id=time_slot_id)

        appointment = Appointments.objects.create(
            category=category,
            personel=personel,
            service=service,
            date=date,
            time_slot=time_slot
        )

        # Redirect to a success page or do any additional processing

        return redirect('appointment_success')

    # Handle GET requests or other scenarios if needed

    return render(request, 'appointments/create_appointments.html')



def appointment_success(request):
    return render(request, 'appointments/appointment_success.html')
