from django.urls import path
#from .views import AppoinmentListView, CreateAppointmentsView,WorkSamplesList
from .views import PersonelAppointmentListView,WorkSamplesListView,appointment_form,update_personels,update_services,save_appointment,appointment_success
urlpatterns = [
#path('alist/',AppoinmentListView.as_view(),name='appoinments')    ,
#path('reserv/',CreateAppointmentsView.as_view(success_url="/success/")),
#path('samples',WorkSamplesList.as_view(),name='samples')
   path('appointment/', appointment_form, name='create_appointment'),
    path('save_appointment/', save_appointment, name='save_appointment'),
    path('appointment_success/', appointment_success, name='appointment_success'),
path('personel/appointment',PersonelAppointmentListView.as_view(),name='personel_appointments'),
path('worksamples',WorkSamplesListView.as_view(),name='worksamples'),
path('update-services', update_services, name='update_services'),
path('update-personels', update_personels, name='update_personels'),

]
