from django import forms
from .models import Appointments, Personel, Service, Category
from dynamic_forms import DynamicFormMixin
from django import forms
from .models import Category, Service, Personel, TimeSlot
# forms.py

from django import forms
from .models import Category, Service, Personel

class AppointmentForm(forms.Form):
    category = forms.ModelChoiceField(queryset=Category.objects.all())
    service = forms.ModelChoiceField(queryset=Service.objects.none())
    personel = forms.ModelChoiceField(queryset=Personel.objects.none())
    date = forms.DateField(widget=forms.DateInput(attrs={'class': 'datepicker'}))
    timeslot = forms.ModelChoiceField(queryset=TimeSlot.objects.none(), widget=forms.Select(attrs={'class': 'timeslot-select'}))

    def __init__(self, *args, **kwargs):
        super(AppointmentForm, self).__init__(*args, **kwargs)
        self.fields['service'].queryset = Service.objects.none()
        self.fields['personel'].queryset = Personel.objects.none()

        if 'category' in self.data:
            try:
                category_id = int(self.data.get('category'))
                self.fields['service'].queryset = Service.objects.filter(category_id=category_id)
            except (ValueError, TypeError):
                pass

        if 'service' in self.data:
            try:
                service_id = int(self.data.get('service'))
                self.fields['personel'].queryset = Personel.objects.filter(services__id=service_id)
                self.fields['timeslot'].queryset = TimeSlot.objects.filter(service_id=service_id)
            except (ValueError, TypeError):
                pass
