from django.db import models
from django.utils import timezone
from django.conf import settings
from datetime import datetime,timedelta
# Create your models here.
#first define abstraction
BOOKING_PERIOD = (
    
    ("15", "15M"),
    ("20", "20M"),
    ("25", "25M"),
    ("30", "30M"),
    ("35", "35M"),
    ("40", "40M"),
    ("45", "45M"),
    ("60", "1H"),
    ("75", "1H 15M"),
    ("90", "1H 30M"),
    ("105", "1H 45M"),
    ("120", "2H"),
    ("150", "2H 30M"),
    ("180", "3H"),
)
     

class Category(models.Model):
    title=models.CharField(max_length=500)
    slug=models.SlugField(unique=True)
    description=models.TextField()

    def __str__(self):
        return self.title

class Service(models.Model):
    slug=models.SlugField()    
    title=models.CharField(max_length=500)
    category=models.ForeignKey("Category",on_delete=models.CASCADE,related_name='services')
    description=models.TextField()    
    def __str__(self):
        return self.title
    

class Personel(models.Model):
    nme=models.CharField(max_length=400)
    services=models.ManyToManyField(Service,blank=True)       
    user =models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    description=models.TextField()
    class Meta: 
       verbose_name_plural = 'Personel'
    
    def __str__(self):
        return self.nme 
    

class Customers(models.Model):
    user=models.OneToOneField(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
  #  phone_number = models.CharField(unique=True, max_length=11)
    class Meta:
        verbose_name_plural = 'Customers'
         
class Appointments(models.Model):    

    personel=models.ForeignKey(Personel,null=True,on_delete=models.CASCADE,blank=True)
    customer=models.ForeignKey(Customers,null=True,on_delete=models.CASCADE)
    service=models.ForeignKey(Service,on_delete=models.CASCADE,null=True)

    time_slot=models.ForeignKey('TimeSlot',on_delete=models.CASCADE)
    booking_code=models.CharField(null=True,max_length=6,)  
    date = models.DateField(help_text="YYYY-MM-DD")
    def __str__(self):
        return f"{self.service.title} with {self.employee.nme} on {self.date}"

class TimeSlot(models.Model):
 #  timeslot = models.IntegerField(choices=TIMESLOT_LIST)   
   start_time = models.TimeField()
   end_time = models.TimeField() 
   available=models.BooleanField(default=True)
   def __str__(self):
        return f"{self.start_time} - {self.end_time}"
    
class Payment(models.Model):
    appointment = models.ForeignKey('Appointments', on_delete=models.CASCADE)
    amount = models.PositiveIntegerField(default=50000)
    date = models.DateTimeField(auto_now_add=True)

class WorkSamples(models.Model):
    title=models.CharField(max_length=255)
    description=models.TextField()
    serviece=models.ForeignKey(Service,on_delete=models.PROTECT,related_name='work_samples')    
    
class Course(models.Model):
    title=models.CharField(max_length=500)
    description=models.TextField()
    duration=models.CharField(max_length=255)
    services=models.ManyToManyField(Service)    


#تنظیم نوبت ها هر نیم ساعت
# تعریف بازه‌های زمانی نیم ساعتی و ذخیره در پایگاه داده
'''start_datetime = datetime.now().replace(hour=8, minute=0, second=0, microsecond=0)
end_datetime = start_datetime.replace(hour=20)
time_slot_duration = timedelta(minutes=30)

current_datetime = start_datetime
while current_datetime + time_slot_duration <= end_datetime:
    start_time = current_datetime.time()
    end_time = (current_datetime + time_slot_duration).time()

    TimeSlot.objects.create(start_time=start_time, end_time=end_time)

    current_datetime += time_slot_duration
    
'''
