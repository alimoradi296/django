from django.contrib import admin
from .models import Appointments,Personel,Customers,Service,Category,TimeSlot
# Register your models here.
admin.site.register(Appointments)
admin.site.register(Personel)
admin.site.register(Category)
admin.site.register(Service)
admin.site.register(Customers)
admin.site.register(TimeSlot)



#@admin.site.register(Appointments)

